DATABASE = {
    'drivername': 'mysql+mysqlconnector:',
    'host': '127.0.0.1',
    'username': 'sarul',
    'password': 'test2006',
    'database': 'features'
}