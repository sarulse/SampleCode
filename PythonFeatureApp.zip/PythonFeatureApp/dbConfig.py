
# Connection string for db connection
connection_strings = {
    "main": "mysql+pymysql://sarul:test2006@127.0.0.1:3306/features"
}